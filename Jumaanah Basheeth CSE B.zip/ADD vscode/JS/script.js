document.getElementById('invoiceForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent form submission

    // Get input values
    const customerName = document.getElementById('customerName').value;
    const customerAddress = document.getElementById('customerAddress').value;
    const itemDescription = document.getElementById('itemDescription').value;
    const quantity = parseInt(document.getElementById('quantity').value);
    const price = parseFloat(document.getElementById('price').value);
    const taxRate = parseFloat(document.getElementById('taxRate').value);

    // Calculate the totals
    const subtotal = quantity * price;
    const taxAmount = (taxRate / 100) * subtotal;
    const totalAmount = subtotal + taxAmount;

    // Create the invoice HTML
    const invoiceHTML = `
        <h3>Invoice</h3>
        <p><strong>Customer Name:</strong> ${customerName}</p>
        <p><strong>Customer Address:</strong> ${customerAddress}</p>
        <h4>Item Details</h4>
        <p><strong>Description:</strong> ${itemDescription}</p>
        <p><strong>Quantity:</strong> ${quantity}</p>
        <p><strong>Price per Unit:</strong> $${price.toFixed(2)}</p>
        <p><strong>Subtotal:</strong> $${subtotal.toFixed(2)}</p>
        <p><strong>Tax (${taxRate}%):</strong> $${taxAmount.toFixed(2)}</p>
        <h4>Total Amount Due: $${totalAmount.toFixed(2)}</h4>
    `;

    // Display the invoice preview
    document.getElementById('invoiceDetails').innerHTML = invoiceHTML;
    document.getElementById('invoicePreview').style.display = 'block';
});

// Function to download the invoice as a PDF
document.getElementById('downloadBtn').addEventListener('click', function () {
    const doc = new jsPDF();
    const invoiceContent = document.getElementById('invoiceDetails').innerHTML;

    doc.html(invoiceContent, {
        callback: function (doc) {
            doc.save('invoice.pdf');
        }
    });
});

// Function to print the invoice
document.getElementById('printBtn').addEventListener('click', function () {
    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Invoice</title></head><body>');
    printWindow.document.write(document.getElementById('invoiceDetails').innerHTML);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
});
